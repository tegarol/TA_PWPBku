    <!-- Main Content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Main Row -->
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="d-lg-inline">Data Customer</h4>
                            <a href="<?= site_url('customer/create') ?>" class="btn btn-success float-lg-right"><i class="fas fa-plus mr-1"></i>Tambah</a>
                        </div>

                        <div class="card-body p-0">
                            <table class="table table-primary table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Customer</th>
                                        <th>NIK Customer</th>
                                        <th style="width: 240px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1;
                                foreach($Customer as $item) : ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td><?= $item->Nama ?></td>
                                            <td><?= $item->NIK ?></td>                                            <td>
                                                <a href="<?= site_url('customer/edit/' . $item->Id) ?>" class="btn btn-warning btn-sm m-1">Edit</a>
                                                <a href="<?= site_url('customer/delete/' . $item->Id) ?>" class="btn btn-danger btn-sm m-1" onclick="return confirm('Anda yakin ingin menghapus data?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Main Row End -->
        </div>
    </section>
    <!-- Main Content End -->
</div>