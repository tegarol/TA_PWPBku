<?php

/**
 * Check user guest
 *
 * @return bool
 */
function isGuest() {
    $ci = get_instance();

    if(!$ci->session->userdata('Email'))
        redirect('auth');

    return TRUE;
}

/**
 * Check user is Authenticated or not
 *
 * @return bool
 */
function isAuth() {
    $ci = get_instance();

    if($ci->session->userdata('Email'))
        redirect('home');

    return TRUE;
}

/**
 * Check if user is Authorization for the request
 *
 * @param String $role
 * 
 * @return int
 */
function isRole($role = 'all', $redirect = TRUE) {
    $ci = get_instance();

    isGuest();

    if($role == 'all')
        return TRUE;

    $role = ($role == 'petugasPendaftaran') ? 1 : 2;

    // Jika role parameter dengan role session sama
    if($ci->session->userdata('role') == $role)
        return TRUE;

    // Jika parameter redirect adalah true
    if($redirect)
        // Jika tidak maka redirect
        show_error('Access Forbidden', 403, '403');
}